/*******************************************************************************
* File Name: Pin_Power.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Pin_Power_H) /* Pins Pin_Power_H */
#define CY_PINS_Pin_Power_H

#include "cytypes.h"
#include "cyfitter.h"
#include "Pin_Power_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    Pin_Power_Write(uint8 value) ;
void    Pin_Power_SetDriveMode(uint8 mode) ;
uint8   Pin_Power_ReadDataReg(void) ;
uint8   Pin_Power_Read(void) ;
uint8   Pin_Power_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Pin_Power_DRIVE_MODE_BITS        (3)
#define Pin_Power_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - Pin_Power_DRIVE_MODE_BITS))

#define Pin_Power_DM_ALG_HIZ         (0x00u)
#define Pin_Power_DM_DIG_HIZ         (0x01u)
#define Pin_Power_DM_RES_UP          (0x02u)
#define Pin_Power_DM_RES_DWN         (0x03u)
#define Pin_Power_DM_OD_LO           (0x04u)
#define Pin_Power_DM_OD_HI           (0x05u)
#define Pin_Power_DM_STRONG          (0x06u)
#define Pin_Power_DM_RES_UPDWN       (0x07u)

/* Digital Port Constants */
#define Pin_Power_MASK               Pin_Power__MASK
#define Pin_Power_SHIFT              Pin_Power__SHIFT
#define Pin_Power_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Pin_Power_PS                     (* (reg32 *) Pin_Power__PS)
/* Port Configuration */
#define Pin_Power_PC                     (* (reg32 *) Pin_Power__PC)
/* Data Register */
#define Pin_Power_DR                     (* (reg32 *) Pin_Power__DR)
/* Input Buffer Disable Override */
#define Pin_Power_INP_DIS                (* (reg32 *) Pin_Power__PC2)


#if defined(Pin_Power__INTSTAT)  /* Interrupt Registers */

    #define Pin_Power_INTSTAT                (* (reg32 *) Pin_Power__INTSTAT)

#endif /* Interrupt Registers */


/***************************************
* The following code is DEPRECATED and 
* must not be used.
***************************************/

#define Pin_Power_DRIVE_MODE_SHIFT       (0x00u)
#define Pin_Power_DRIVE_MODE_MASK        (0x07u << Pin_Power_DRIVE_MODE_SHIFT)


#endif /* End Pins Pin_Power_H */


/* [] END OF FILE */
