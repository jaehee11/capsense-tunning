 /* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
// /* unit8 widget is in Widgets constants definition of CapSense_CSHL.h */

#include <project.h>
#include <header.h>
#include "CapSense_CSHL.h"

//#define hawkeye

static void init_system(void);


extern uint16 CapSense_SensorSignal[CapSense_TOTAL_SENSOR_COUNT];
extern uint16 CapSense_sensorRaw[CapSense_TOTAL_SENSOR_COUNT];
extern uint16 CapSense_sensorBaseline[CapSense_TOTAL_SENSOR_COUNT];
extern uint8 CapSense_sensorOnMask[(((CapSense_TOTAL_SENSOR_COUNT - 1u) / 8u) + 1u)];

extern void report_debug_data( void );

//Define a structure to hold the RawCount, DifferenceCount, BaseLine, Sensor Status and slider centroid details of requested sensor.
//This structure will be used as I2C buffer for communicating with I2C master.
#define BUFFER_SIZE     (31u)
uint8 ezI2cBuffer[BUFFER_SIZE];

/* Functions */
CY_ISR_PROTO (WDT_ISR);
unsigned char sleep_flag = 0;
uint32 ILODelayCycles_0 = 0;
uint32 ILODelayCycles_1 = 0;

/* Adjust WDT time */
#define WDT_MATCH_VALUE_50MS		(32 * 50) //50ms (IL0~32K)
#define WDT_MATCH_VALUE_80MS		(32 * 80) //60ms (IL0~32K)
#define WDT_MATCH_VALUE_100MS		(32 * 100) //200ms (IL0~32K)
#define WDT_MATCH_VALUE_20MS		(32 * 20) //200ms (IL0~32K)
#define WDT_MATCH_VALUE_200MS		(32 * 200) //200ms (IL0~32K)
#define WDT_MATCH_VALUE_2000MS		(32 * 2000) //2000ms (IL0~32K)

unsigned char One_Key_Scan_flag = 0;
unsigned char pre_key = 0;
unsigned char pre_one_key = 0;
unsigned char zig_flag = 0;

unsigned char multikey_flag = 0;

unsigned char counter_5s = 0;

unsigned char key_scan_count;
uint8 bButtonTouchOnOffStatus;
unsigned char comm_change = 0;
unsigned char pre_CapSense_SensorOnMask[4];

void multikey_check();

void baseline_check();
extern void CapSense_SetModulationIDAC(uint32 sensor, uint32 modIdacValue);
extern unsigned char temp[25];
unsigned char F_thersholds[25];
unsigned char IDAC_val[25];

#if 1
//-------------------IMD_No_Aluminum----------------------------------------------------------//
//------------------------------------0----1----2----3----4----5----6----7---8----9
unsigned int default_baseline[26] = {2875,1415,2880,2765,2885,1404,2845,1390,735,2865,
                                     1390,1400,2865,1420,2750,2730,2770,2735,1410,2855,
                                     2740,2760,1410,2820,1420,2885};
#endif

int main(void)
{
      
	/* Enable global interrupt */
	CyGlobalIntEnable;
    
    EZI2C_EzI2CSetBuffer1(BUFFER_SIZE, READ_ONLY_OFFSET, ezI2cBuffer);
    EZI2C_Start();
    
	/* Initialize and start the CapSense component */
	CapSense_Start();			
	
	/* Initialize all CapSense baselines */
	CapSense_InitializeAllBaselines();
    
    unsigned char k = 0;
    for(k = 0 ; k < 26 ; k++)
    {
        IDAC_val[k] = CapSense_GetModulationIDAC(k);
        F_thersholds[k] = CapSense_GetFingerThreshold(k);
    }
    
    init_system();
    
    CySysWdtEnable(CY_SYS_WDT_COUNTER1_MASK);

    CyDelay(20u);
    CyDelay(20u);
        
	while(1)	/* Sensor Scanning Loop */
	{                
        unsigned char i = 0;
        
        if(hawkeye_data_Read() == 0u)   //zig i/o에 low 들어올 때
        {
            comm_change = 1;            //zig 통신 모드 플래그 set
        }
        
        if(sleep_flag == 0) // 일반 동작 상태(Sleepmode가 아닌 상태)
        {
            if(key_scan_count  > 0)
            {        
                key_scan_count --;    
                
        		/* Start scanning all enabled sensors */
        		CapSense_ScanEnabledWidgets();
        		
                /* Wait for scanning to complete */
        		while(CapSense_IsBusy() != 0)
                {
                }
                
                baseline_check();            

        		/* Update all baselines */
        		CapSense_UpdateEnabledBaselines();
                
                /* Is any sensor active? */
                CapSense_CheckIsAnyWidgetActive();    
                        
                if(counter_5s >= 100)    //5초가 지나면 multikey 동작(통신 주기가 50ms 일 때)
                {
                    if(zig_flag == 0)
                    {
                       multikey_check();          
                    }
                }     
                
                if(multikey_flag == 0)      //멀티키가 아니면 pre_buffer에 업데이트
                {
                    pre_CapSense_SensorOnMask[0] = CapSense_SensorOnMask[0];
                    pre_CapSense_SensorOnMask[1] = CapSense_SensorOnMask[1];
                    pre_CapSense_SensorOnMask[2] = CapSense_SensorOnMask[2];
                    pre_CapSense_SensorOnMask[3] = CapSense_SensorOnMask[3];
                }
                
                if(multikey_flag == 0)
                {
                    if(CapSense_SensorOnMask[3] == 0x02) 
                    {
                        Pin_Power_Write(0);
                    }
                    else
                    {
                        Pin_Power_Write(1);
                    }
                }
                else
                {
                    if(pre_CapSense_SensorOnMask[3] == 0x02) 
                    {
                        Pin_Power_Write(0);
                    }
                    else
                    {
                        Pin_Power_Write(1);
                    }
                }
            }
            
            if(comm_change == 0)    //Sub와 통신 
            {   
                if (0u != (EZI2C_EzI2CGetActivity() & EZI2C_EZI2C_STATUS_WRITE1))
                {
                    key_scan_count = 5;
                    
                    if(counter_5s < 100)
                        counter_5s ++;
                    
                    if(ezI2cBuffer[2] == 0x01)
                    {
                        sleep_flag = 1;
                        EZI2C_Stop();
                    }
                    if(multikey_flag == 0)
                    {          
                        ezI2cBuffer[0] = 0xEB;                             //Model
                        ezI2cBuffer[1] = CapSense_SensorOnMask[0];         //key 0
                        ezI2cBuffer[2] = CapSense_SensorOnMask[1];         //key 1  
                        ezI2cBuffer[3] = 0x62;                             //Version(AL_0x60, No_AL_0x61, Better 0x51)
                        ezI2cBuffer[4] = CapSense_SensorOnMask[2];         //key 2   
                        if(CapSense_SensorOnMask[3] & 0x02)
                        {
                            ezI2cBuffer[5] = (CapSense_SensorOnMask[3] & 0x01);//key 3
                        }
                        else
                        {
                            ezI2cBuffer[5] = CapSense_SensorOnMask[3];         //key 3
                        }
                        ezI2cBuffer[6] = 0x00;                                 //dummy
                        ezI2cBuffer[7] = (uint8) (ezI2cBuffer[0] + ezI2cBuffer[1] + ezI2cBuffer[2] + ezI2cBuffer[3] 
                                            + ezI2cBuffer[4]+ ezI2cBuffer[5] + ezI2cBuffer[6]);
                    }
                    else
                    {
                        ezI2cBuffer[0] = 0xEB;                             //Model
                        ezI2cBuffer[1] = pre_CapSense_SensorOnMask[0];     //key 0
                        ezI2cBuffer[2] = pre_CapSense_SensorOnMask[1];     //key 1   
                        ezI2cBuffer[3] = 0x62;                             //VersionVersion(AL_0x60, No_AL_0x61, Better 0x51)
                        ezI2cBuffer[4] = pre_CapSense_SensorOnMask[2];     //key 2                  
                        ezI2cBuffer[5] = pre_CapSense_SensorOnMask[3];     //key3
                        ezI2cBuffer[6] = 0x00;                             //dummy
                        ezI2cBuffer[7] = (uint8) (ezI2cBuffer[0] + ezI2cBuffer[1] + ezI2cBuffer[2] 
                                                    + ezI2cBuffer[3] + ezI2cBuffer[4] + ezI2cBuffer[5] + ezI2cBuffer[6]);
                    }
                }       
            }
            else    //comm_change == 1  25키가 눌린 상태에서 지그모드 핀으로 Low가 들어옴
            {
                if (0u != (EZI2C_EzI2CGetActivity() & EZI2C_EZI2C_STATUS_WRITE1))
                {
                    key_scan_count = 5;
                  
                    ezI2cBuffer[0] = 0xEB;  
                    ezI2cBuffer[1] = (uint8) (CapSense_SensorSignal[0]/2);         //key 0
                    ezI2cBuffer[2] = (uint8) (CapSense_SensorSignal[1]/2);         //key 1
                    ezI2cBuffer[3] = (uint8) (CapSense_SensorSignal[2]/2);         //key 2
                    ezI2cBuffer[4] = (uint8) (CapSense_SensorSignal[3]/2);         //key 3
                    ezI2cBuffer[5] = (uint8) (CapSense_SensorSignal[4]/2);         //key 4
                    ezI2cBuffer[6] = (uint8) (CapSense_SensorSignal[5]/2);         //key 5
                    ezI2cBuffer[7] = (uint8) (CapSense_SensorSignal[6]/2);         //key 6
                    ezI2cBuffer[8] = (uint8) (CapSense_SensorSignal[7]/2);         //key 7
                    ezI2cBuffer[9] = (uint8) (CapSense_SensorSignal[8]/2);         //key 8
                    ezI2cBuffer[10] = (uint8) (CapSense_SensorSignal[9]/2);         //key 9
                    ezI2cBuffer[11] = (uint8) (CapSense_SensorSignal[10]/2);         //key 10
                    ezI2cBuffer[12] = (uint8) (CapSense_SensorSignal[11]/2);         //key 11
                    ezI2cBuffer[13] = (uint8) (CapSense_SensorSignal[12]/2);         //key 12
                    ezI2cBuffer[14] = (uint8) (CapSense_SensorSignal[13]/2);         //key 13
                    ezI2cBuffer[15] = (uint8) (CapSense_SensorSignal[14]/2);         //key 14
                    ezI2cBuffer[16] = (uint8) (CapSense_SensorSignal[15]/2);         //key 15
                    ezI2cBuffer[17] = (uint8) (CapSense_SensorSignal[16]/2);         //key 16
                    ezI2cBuffer[18] = (uint8) (CapSense_SensorSignal[17]/2);         //key 17
                    ezI2cBuffer[19] = (uint8) (CapSense_SensorSignal[18]/2);         //key 18
                    ezI2cBuffer[20] = (uint8) (CapSense_SensorSignal[19]/2);         //key 19
                    ezI2cBuffer[21] = (uint8) (CapSense_SensorSignal[20]/2);         //key 20
                    ezI2cBuffer[22] = (uint8) (CapSense_SensorSignal[21]/2);         //key 21
                    ezI2cBuffer[23] = (uint8) (CapSense_SensorSignal[22]/2);         //key 22
                    ezI2cBuffer[24] = (uint8) (CapSense_SensorSignal[23]/2);         //key 23
                    ezI2cBuffer[25] = (uint8) (CapSense_SensorSignal[24]/2);         //key 24
                    ezI2cBuffer[26] = (uint8) (CapSense_SensorSignal[25]/2);         //key 25
                    ezI2cBuffer[27] = 0x00; //Dummy
                    ezI2cBuffer[28] = 0x62; //VersionVersion(AL_0x60, No_AL_0x61, Better 0x51)
                    //-------------------------------------------
                    ezI2cBuffer[29] = 0x00; //Dummy
                    ezI2cBuffer[30] = (uint8) (ezI2cBuffer[0] + ezI2cBuffer[1] + ezI2cBuffer[2] + ezI2cBuffer[3] + ezI2cBuffer[4]
                                                 + ezI2cBuffer[5] + ezI2cBuffer[6] + ezI2cBuffer[7] + ezI2cBuffer[8] + ezI2cBuffer[9]
                                                 + ezI2cBuffer[10] + ezI2cBuffer[11] + ezI2cBuffer[12] + ezI2cBuffer[13] + ezI2cBuffer[14]
                                                 + ezI2cBuffer[15] + ezI2cBuffer[16] + ezI2cBuffer[17] + ezI2cBuffer[18] + ezI2cBuffer[19]
                                                 + ezI2cBuffer[20] + ezI2cBuffer[21] + ezI2cBuffer[22] + ezI2cBuffer[23] + ezI2cBuffer[24]
                                                 + ezI2cBuffer[25] + ezI2cBuffer[26] + ezI2cBuffer[27] + ezI2cBuffer[28] + ezI2cBuffer[29]);
                    
                }                
            }
        }  
        
        else    //sleep_flag == 1 슬립모드
        {
            /* Enable the WDT interrupt in SRSS INTR mask register */
            CySysWdtEnable(CY_SYS_WDT_COUNTER0_MASK);    //WDT counter 0 enable 
                
            /* CapSense enter sleep */
            CapSense_Sleep();
                    
            /* Enter deep sleep */
            CySysPmDeepSleep();
                    
            /* CapSense Wakeup */
            CapSense_Wakeup();
                    
            //---------------------------------------------------------------------------------
            /* Scan only the Button 25 sensor */
            CapSense_ScanSensor(CapSense_BUTTON25__BTN);
            /* Wait for scanning to complete */
            while(CapSense_IsBusy() != 0);
            /* Update the baseline of only the Button 25 sensor*/
           	CapSense_UpdateSensorBaseline(CapSense_BUTTON25__BTN);
            /* Check if the Button 25 sensor is active */
            bButtonTouchOnOffStatus = CapSense_CheckIsWidgetActive(CapSense_BUTTON25__BTN);
                    
            CapSense_ScanSensor(CapSense_BUTTON0__BTN);
            while(CapSense_IsBusy() != 0);
            CapSense_UpdateSensorBaseline(CapSense_BUTTON0__BTN);
            CapSense_CheckIsWidgetActive(CapSense_BUTTON0__BTN);
                    
            CapSense_ScanSensor(CapSense_BUTTON1__BTN);
            while(CapSense_IsBusy() != 0);
            CapSense_UpdateSensorBaseline(CapSense_BUTTON1__BTN);
            CapSense_CheckIsWidgetActive(CapSense_BUTTON1__BTN);
                    
            CapSense_ScanSensor(CapSense_BUTTON2__BTN);
            while(CapSense_IsBusy() != 0);
            CapSense_UpdateSensorBaseline(CapSense_BUTTON2__BTN);
            CapSense_CheckIsWidgetActive(CapSense_BUTTON2__BTN);
                    
            CapSense_ScanSensor(CapSense_BUTTON3__BTN);
            while(CapSense_IsBusy() != 0);
            CapSense_UpdateSensorBaseline(CapSense_BUTTON3__BTN);
            CapSense_CheckIsWidgetActive(CapSense_BUTTON3__BTN);
                 
            CapSense_ScanSensor(CapSense_BUTTON4__BTN);
            while(CapSense_IsBusy() != 0);
            CapSense_UpdateSensorBaseline(CapSense_BUTTON4__BTN);
            CapSense_CheckIsWidgetActive(CapSense_BUTTON4__BTN);
                  
            CapSense_ScanSensor(CapSense_BUTTON5__BTN);
            while(CapSense_IsBusy() != 0);
            CapSense_UpdateSensorBaseline(CapSense_BUTTON5__BTN);
            CapSense_CheckIsWidgetActive(CapSense_BUTTON5__BTN); 
            
            CapSense_ScanSensor(CapSense_BUTTON6__BTN);
            while(CapSense_IsBusy() != 0);
            CapSense_UpdateSensorBaseline(CapSense_BUTTON6__BTN);
            CapSense_CheckIsWidgetActive(CapSense_BUTTON6__BTN);
                            
            CapSense_ScanSensor(CapSense_BUTTON7__BTN);
            while(CapSense_IsBusy() != 0);
            CapSense_UpdateSensorBaseline(CapSense_BUTTON7__BTN);
            CapSense_CheckIsWidgetActive(CapSense_BUTTON7__BTN);
                    
            CapSense_ScanSensor(CapSense_BUTTON8__BTN);
            while(CapSense_IsBusy() != 0);
            CapSense_UpdateSensorBaseline(CapSense_BUTTON8__BTN);
            CapSense_CheckIsWidgetActive(CapSense_BUTTON8__BTN);
                    
            CapSense_ScanSensor(CapSense_BUTTON9__BTN);
            while(CapSense_IsBusy() != 0);
            CapSense_UpdateSensorBaseline(CapSense_BUTTON9__BTN);
            CapSense_CheckIsWidgetActive(CapSense_BUTTON9__BTN);
                  
            CapSense_ScanSensor(CapSense_BUTTON24__BTN);
            while(CapSense_IsBusy() != 0);
            CapSense_UpdateSensorBaseline(CapSense_BUTTON24__BTN);
            CapSense_CheckIsWidgetActive(CapSense_BUTTON24__BTN);
            /* Filter */
            //더블키 체크 후 눌렸으면 키 제거
            if( ((CapSense_SensorOnMask[3] == 0x02) && (CapSense_SensorOnMask[0] & 0xff)) ||
                ((CapSense_SensorOnMask[3] == 0x02) && (CapSense_SensorOnMask[1] & 0x03)) ||
                ((CapSense_SensorOnMask[3] == 0x02) && (CapSense_SensorOnMask[3] & 0x01)))
            {
                bButtonTouchOnOffStatus = 0;
            }
            //----------------------------------------------------------------------------------          
            if( bButtonTouchOnOffStatus )
            {
                EZI2C_Start();
                sleep_flag = 0;   
                Pin_Power_Write(0);
                CySysWdtDisable(CY_SYS_WDT_COUNTER0_MASK);    //WDT counter 0 enable 
            }
        }
        
        /*Rawcount abnormal algorithm*/
        for(i=0;i<CapSense_TOTAL_SENSOR_COUNT;i++)
        {
            if(CapSense_sensorRaw[i] < 100)
            {
                CySoftwareReset();
            }
        }

        CySysWdtResetCounters(CY_SYS_WDT_COUNTER1_RESET);
        
        #ifdef hawkeye
                    report_debug_data();          
        #endif
    
    
	}
}

void baseline_check()
{
    //channel 0 - 25
    unsigned char i = 0;
    for( i = 0; i < 26 ; i++)
    {
        if( (CapSense_sensorBaseline[i] > ((default_baseline[i]*12)/10)) && (CapSense_GetModulationIDAC(i) == IDAC_val[i]) ) 
        {
            CapSense_SetModulationIDAC(i,( (IDAC_val[i]*135)/100));
            CapSense_SetFingerThreshold(i,((F_thersholds[i]*85)/100));
        }
        //else if( (CapSense_sensorBaseline[i] < ((((default_baseline[i]*74)/100)*11)/10)) && (CapSense_GetModulationIDAC(i) == ((IDAC_val[i]*135) / 100) ) )
        else if( (CapSense_sensorBaseline[i] < ((default_baseline[i]*8)/10)) && (CapSense_GetModulationIDAC(i) == ((IDAC_val[i]*135)/100) ) )
        {
            CapSense_SetModulationIDAC(i,IDAC_val[i]);
            CapSense_SetFingerThreshold(i,F_thersholds[i]);
            CapSense_InitializeSensorBaseline(i);
        }  
        #ifdef hawkeye
            //temp[i] = CapSense_GetModulationIDAC(i);
            temp[i] = CapSense_GetFingerThreshold(i);
        #endif
    }
}

void multikey_check()
{
    unsigned char i, a, count_multi_key = 0;
    
    multikey_flag = 0;
    
    if(CapSense_SensorOnMask[3] & 0x02)
    {
        count_multi_key++;
    }
    if( (CapSense_SensorOnMask[3] & 0x01) )
    {
        count_multi_key++;
    }
    
    for(i = 0 ; i < 8 ; i++)
    {
        a = (0x01 << i);
        if( (CapSense_SensorOnMask[0] & a) )
        {
            count_multi_key++;
        }
    }
    for(i = 0 ; i < 7 ; i++)
    {
        a = (0x01 << i);
        if( (CapSense_SensorOnMask[1] & a) )
        {
            count_multi_key++;
        }
    }
    
    if( count_multi_key >= 2 )
    {        
        multikey_flag = 1;
    }      
}

/*============================================================================
Name    :   init_system
------------------------------------------------------------------------------
Purpose :   initialise host app, pins, watchdog, etc
Input   :   n/a
Output  :   n/a
Notes   :
============================================================================*/
static void init_system(void)
{
    /* Configure the wake up period to 100ms */			
    ILODelayCycles_0 = WDT_MATCH_VALUE_20MS;		
    //ILODelayCycles_0 = WDT_MATCH_VALUE_50MS;	
    //ILODelayCycles_0 = WDT_MATCH_VALUE_80MS;		
    //ILODelayCycles_0 = WDT_MATCH_VALUE_100MS;			
    //ILODelayCycles_0 = WDT_MATCH_VALUE_200MS;			
    ILODelayCycles_1 = WDT_MATCH_VALUE_2000MS;
    
    /* Map the WatchDog_ISR vector to the WDT_ISR */
    isr_WDT_StartEx(WDT_ISR); 
    
    //WTD Counter0 interrupt Init
    CySysWdtWriteMode(CY_SYS_WDT_COUNTER0,CY_SYS_WDT_MODE_INT);       
    CySysWdtWriteMatch(CY_SYS_WDT_COUNTER0,ILODelayCycles_0);       
	CySysWdtWriteClearOnMatch(CY_SYS_WDT_COUNTER0, 1u); // clear on match enable
    
    /* Enable WDT counters 0 and 1 cascade */
	CySysWdtWriteCascade(CY_SYS_WDT_CASCADE_NONE);
    
    //WTD Counter1 interrupt Init
    CySysWdtWriteMode(CY_SYS_WDT_COUNTER1,CY_SYS_WDT_MODE_RESET);       
    CySysWdtWriteMatch(CY_SYS_WDT_COUNTER1,ILODelayCycles_1);       
	CySysWdtWriteClearOnMatch(CY_SYS_WDT_COUNTER1, 1u); // clear on match enable
}

/******************************************************************************
* Function Name: WDT_ISR_Handler
*******************************************************************************
*
* Summary:
* Interrupt Service Routine for the watchdog timer interrupt. The periodicity 
* of the interrupt is depended on the match value written into the counter 
* register using API - CySysWdtWriteMatch().
*
******************************************************************************/
CY_ISR(WDT_ISR)
{
	/* Clear WDT interrupt */ 
	CySysWdtClearInterrupt(CY_SYS_WDT_COUNTER0_INT);
    CySysWdtClearInterrupt(CY_SYS_WDT_COUNTER1_INT);    
}

/* [] END OF FILE */
