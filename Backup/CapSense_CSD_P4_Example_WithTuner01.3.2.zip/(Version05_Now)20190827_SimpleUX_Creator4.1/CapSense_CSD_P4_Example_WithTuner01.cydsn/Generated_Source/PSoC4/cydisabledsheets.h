#ifndef INCLUDED_CYDISABLEDSHEETS_H
#define INCLUDED_CYDISABLEDSHEETS_H

#define Schematic__DISABLED 1u /* Schematic */
#define IMD_Window_AL___DISABLED 1u /* IMD_Window(AL) */
#define Active_mode__DISABLED 1u /* Active mode */

#endif /* INCLUDED_CYDISABLEDSHEETS_H */
