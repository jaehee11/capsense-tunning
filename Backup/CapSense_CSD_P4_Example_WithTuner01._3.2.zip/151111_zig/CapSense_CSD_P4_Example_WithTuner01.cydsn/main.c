 /* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
// /* unit8 widget is in Widgets constants definition of CapSense_CSHL.h */

#include <project.h>
#include <header.h>
#include "CapSense_CSHL.h"

//#define hawkeye

static void init_system(void);

extern uint16 CapSense_SensorSignal[CapSense_TOTAL_SENSOR_COUNT];
extern uint16 CapSense_sensorRaw[CapSense_TOTAL_SENSOR_COUNT];
extern uint16 CapSense_sensorBaseline[CapSense_TOTAL_SENSOR_COUNT];
extern uint8 CapSense_sensorOnMask[(((CapSense_TOTAL_SENSOR_COUNT - 1u) / 8u) + 1u)];

extern void report_debug_data( void );

//Define a structure to hold the RawCount, DifferenceCount, BaseLine, Sensor Status and slider centroid details of requested sensor.
//This structure will be used as I2C buffer for communicating with I2C master.
uint8 i2cReadBuffer [READ_BUFFER_SIZE];
uint8 i2cWriteBuffer[WRITE_BUFFER_SIZE];


/* Functions */
CY_ISR_PROTO (WDT_ISR);
unsigned char sleep_flag = 0;
uint32 ILODelayCycles_0 = 0;
uint32 ILODelayCycles_1 = 0;

/* Adjust WDT time */
#define WDT_MATCH_VALUE_50MS		(32 * 50) //30ms (IL0~32K)
#define WDT_MATCH_VALUE_100MS		(32 * 100) //200ms (IL0~32K)
#define WDT_MATCH_VALUE_20MS		(32 * 20) //200ms (IL0~32K)
#define WDT_MATCH_VALUE_200MS		(32 * 200) //200ms (IL0~32K)
#define WDT_MATCH_VALUE_2000MS		(32 * 2000) //2000ms (IL0~32K)

unsigned char One_Key_Scan_flag = 0;
unsigned char pre_key = 0;
unsigned char pre_one_key = 0;
unsigned char zig_flag = 0;

unsigned char multikey_flag = 0;

unsigned char counter_5s = 0;

unsigned char key_scan_count;
uint8 bButtonTouchOnOffStatus;
unsigned char comm_change = 0;
unsigned char pre_CapSense_SensorOnMask[4];

void multikey_check();


int main(void)
{
      
	/* Enable global interrupt */
	CyGlobalIntEnable;
	
    I2CS_I2CSlaveInitReadBuf (i2cReadBuffer,  READ_BUFFER_SIZE);
    I2CS_I2CSlaveInitWriteBuf(i2cWriteBuffer, WRITE_BUFFER_SIZE);
    I2CS_Start();
    
	/* Initialize and start the CapSense component */
	CapSense_Start();			
	
	/* Initialize all CapSense baselines */
	CapSense_InitializeAllBaselines();
    
    init_system();
    
    CySysWdtEnable(CY_SYS_WDT_COUNTER1_MASK);

    CyDelay(20u);
    CyDelay(20u);
        
	while(1)	/* Sensor Scanning Loop */
	{                
        unsigned char i = 0;
        
        if( zig_flag == 1 ) // 25키가 눌렸을 때
        {
            if(hawkeye_data_Read() == 0u)   //zig i/o에 low 들어올 때
                comm_change = 1;            //zig 통신 모드 플래그 set
        }
        
        if(sleep_flag == 0) // 일반 동작 상태(Sleepmode가 아닌 상태)
        {
            if(key_scan_count  > 0)
            {        
                key_scan_count --;    
        		/* Start scanning all enabled sensors */
        		CapSense_ScanEnabledWidgets();
        		
                /* Wait for scanning to complete */
        		while(CapSense_IsBusy() != 0);

        		/* Update all baselines */
        		CapSense_UpdateEnabledBaselines();
                
                /* Is any sensor active? */
                CapSense_CheckIsAnyWidgetActive();    
                
                //test mode 확인( 전체키 들어오면 zig_flag set )
                if( (CapSense_SensorOnMask[0] == 0xff) && (CapSense_SensorOnMask[1] == 0xff) && (CapSense_SensorOnMask[2] == 0xff) && (CapSense_SensorOnMask[3] == 0x01) )
                {
                    zig_flag = 1;
                }
                         
                
                if(counter_5s >= 100)    //5초가 지나면 multikey 동작(통신 주기가 50ms 일 때)
                {
                    if(zig_flag == 0)
                    {
                       multikey_check();
                    }
                }     
                
                if(multikey_flag == 0)      //멀티키가 아니면 pre_buffer에 업데이트
                {
                    pre_CapSense_SensorOnMask[0] = CapSense_SensorOnMask[0];
                    pre_CapSense_SensorOnMask[1] = CapSense_SensorOnMask[1];
                    pre_CapSense_SensorOnMask[2] = CapSense_SensorOnMask[2];
                    pre_CapSense_SensorOnMask[3] = CapSense_SensorOnMask[3];
                }
                
                if(multikey_flag == 0)
                {
                    if(CapSense_SensorOnMask[3]) 
                    {
                        Pin_Power_Write(0);
                    }
                    else
                    {
                        Pin_Power_Write(1);
                    }
                }
                else
                {
                    if(pre_CapSense_SensorOnMask[3]) 
                    {
                        Pin_Power_Write(0);
                    }
                    else
                    {
                        Pin_Power_Write(1);
                    }
                }
            }
           
            if(comm_change == 0)    //Sub와 통신 
            {   
                if (0u != (I2CS_I2CSlaveStatus() & I2CS_I2C_SSTAT_WR_CMPLT))
                {
                    /* Check packet length */
                    if (PACKET_SIZE == I2CS_I2CSlaveGetWriteBufSize())
                    {
                        /* Check start and end of packet markers */
                        if (i2cWriteBuffer[2] == 0x01)
                        {
                           sleep_flag = 1;   
                           I2CS_Stop();
                        }
                    }

                    /* Clear slave write buffer and status */
                    I2CS_I2CSlaveClearWriteBuf();
                    (void) I2CS_I2CSlaveClearWriteStatus();

                    /* Update read buffer */
                    
                    key_scan_count = 4;
                }        

                /* Read complete: expose buffer to master */
                if (0u != (I2CS_I2CSlaveStatus() & I2CS_I2C_SSTAT_RD_CMPLT))
                {
                    if(counter_5s < 100)
                        counter_5s ++;
                    
                    /* Clear slave read buffer and status */
                    I2CS_I2CSlaveClearReadBuf();
                    (void) I2CS_I2CSlaveClearReadStatus();
                    
                    if(multikey_flag == 0)  //지정 멀티키 이외의 통신
                    {
                        i2cReadBuffer[0] = 0xEB;                             //Model
                        i2cReadBuffer[1] = CapSense_sensorOnMask[0];         //key 0
                        i2cReadBuffer[2] = CapSense_sensorOnMask[1];         //key 1   
                        //------Washer & Dryer Version---------------
                        //i2cReadBuffer[3] = 0x06;                             //Version(Washer 0x50, Dryer 0x05)
                        i2cReadBuffer[3] = 0x60;                             //Version(Washer 0x50, Dryer 0x05)
                        //-------------------------------------------
                        i2cReadBuffer[4] = CapSense_sensorOnMask[2];         //key 2                  
                        i2cReadBuffer[5] = (uint8) (i2cReadBuffer[0] + i2cReadBuffer[1] + i2cReadBuffer[2] + i2cReadBuffer[3] + i2cReadBuffer[4]);
                    }
                    else        //지정 멀티키 입력시 통신
                    {
                        i2cReadBuffer[0] = 0xEB;                             //Model
                        i2cReadBuffer[1] = pre_CapSense_SensorOnMask[0];         //key 0
                        i2cReadBuffer[2] = pre_CapSense_SensorOnMask[1];         //key 1   
                        //------Washer & Dryer Version---------------
                        //i2cReadBuffer[3] = 0x06;                             //Version(Washer 0x50, Dryer 0x05)
                        i2cReadBuffer[3] = 0x60;                             //Version(Washer 0x50, Dryer 0x05)
                        //-------------------------------------------
                        i2cReadBuffer[4] = pre_CapSense_SensorOnMask[2];         //key 2                  
                        i2cReadBuffer[5] = (uint8) (i2cReadBuffer[0] + i2cReadBuffer[1] + i2cReadBuffer[2] + i2cReadBuffer[3] + i2cReadBuffer[4]);
                    }
                     
                    
                    key_scan_count = 4;     
                }
            }
            else    //comm_change == 1  25키가 눌린 상태에서 지그모드 핀으로 Low가 들어옴
            {
                if (0u != (I2CS_I2CSlaveStatus() & I2CS_I2C_SSTAT_RD_CMPLT))
                {
                    /* Clear slave read buffer and status */
                    I2CS_I2CSlaveClearReadBuf();
                    (void) I2CS_I2CSlaveClearReadStatus();
                  
                    i2cReadBuffer[0] = 0xEB;  
                    i2cReadBuffer[1] = (uint8) (CapSense_sensorSignal[0]/10);         //key 0
                    i2cReadBuffer[2] = (uint8) (CapSense_sensorSignal[1]/10);         //key 1
                    i2cReadBuffer[3] = (uint8) (CapSense_sensorSignal[2]/10);         //key 2
                    i2cReadBuffer[4] = (uint8) (CapSense_sensorSignal[3]/10);         //key 3
                    i2cReadBuffer[5] = (uint8) (CapSense_sensorSignal[4]/10);         //key 4
                    i2cReadBuffer[6] = (uint8) (CapSense_sensorSignal[5]/10);         //key 5
                    i2cReadBuffer[7] = (uint8) (CapSense_sensorSignal[6]/10);         //key 6
                    i2cReadBuffer[8] = (uint8) (CapSense_sensorSignal[7]/10);         //key 7
                    i2cReadBuffer[9] = (uint8) (CapSense_sensorSignal[8]/10);         //key 8
                    i2cReadBuffer[10] = (uint8) (CapSense_sensorSignal[9]/10);         //key 9
                    i2cReadBuffer[11] = (uint8) (CapSense_sensorSignal[10]/10);         //key 10
                    i2cReadBuffer[12] = (uint8) (CapSense_sensorSignal[11]/10);         //key 11
                    i2cReadBuffer[13] = (uint8) (CapSense_sensorSignal[12]/10);         //key 12
                    i2cReadBuffer[14] = (uint8) (CapSense_sensorSignal[13]/10);         //key 13
                    i2cReadBuffer[15] = (uint8) (CapSense_sensorSignal[14]/10);         //key 14
                    i2cReadBuffer[16] = (uint8) (CapSense_sensorSignal[15]/10);         //key 15
                    i2cReadBuffer[17] = (uint8) (CapSense_sensorSignal[16]/10);         //key 16
                    i2cReadBuffer[18] = (uint8) (CapSense_sensorSignal[17]/10);         //key 17   
                    i2cReadBuffer[19] = (uint8) (CapSense_sensorSignal[18]/10);         //key 18
                    i2cReadBuffer[20] = (uint8) (CapSense_sensorSignal[19]/10);         //key 19
                    i2cReadBuffer[21] = (uint8) (CapSense_sensorSignal[20]/10);         //key 20
                    i2cReadBuffer[22] = (uint8) (CapSense_sensorSignal[21]/10);         //key 21
                    i2cReadBuffer[23] = (uint8) (CapSense_sensorSignal[22]/10);         //key 22
                    i2cReadBuffer[24] = (uint8) (CapSense_sensorSignal[23]/10);         //key 23
                    i2cReadBuffer[25] = (uint8) (CapSense_sensorSignal[24]/10);         //key 24
                    i2cReadBuffer[26] = 0x00; //Dummy
                    //------Washer & Dryer Version---------------
                    //i2cReadBuffer[27] = 0x06;                             //Version(Washer 0x50, Dryer 0x05)
                    i2cReadBuffer[27] = 0x60;                             //Version(Washer 0x50, Dryer 0x05)
                    //-------------------------------------------
                    i2cReadBuffer[28] = 0x00; //Dummy
                    i2cReadBuffer[29] = (uint8) (i2cReadBuffer[0] + i2cReadBuffer[1] + i2cReadBuffer[2] + i2cReadBuffer[3] + i2cReadBuffer[4]
                                                 + i2cReadBuffer[5] + i2cReadBuffer[6] + i2cReadBuffer[7] + i2cReadBuffer[8] + i2cReadBuffer[9]
                                                 + i2cReadBuffer[10] + i2cReadBuffer[11] + i2cReadBuffer[12] + i2cReadBuffer[13] + i2cReadBuffer[14]
                                                 + i2cReadBuffer[15] + i2cReadBuffer[16] + i2cReadBuffer[17] + i2cReadBuffer[18] + i2cReadBuffer[19]
                                                 + i2cReadBuffer[20] + i2cReadBuffer[21] + i2cReadBuffer[22] + i2cReadBuffer[23] + i2cReadBuffer[24]
                                                 + i2cReadBuffer[25] + i2cReadBuffer[26] + i2cReadBuffer[27] + i2cReadBuffer[28]);
                    
                }                
                    key_scan_count = 4;
            }
        }  
        
        else    //sleep_flag == 1 슬립모드
        {
            /* Enable the WDT interrupt in SRSS INTR mask register */
            CySysWdtEnable(CY_SYS_WDT_COUNTER0_MASK);    //WDT counter 0 enable 
                
            /* CapSense enter sleep */
            CapSense_Sleep();
                    
            /* Enter deep sleep */
            CySysPmDeepSleep();
                    
            /* CapSense Wakeup */
            CapSense_Wakeup();
                    
            //---------------------------------------------------------------------------------
            /* Scan only the Button 24 sensor */
            CapSense_ScanSensor(CapSense_BUTTON24__BTN);
            /* Wait for scanning to complete */
            while(CapSense_IsBusy() != 0);
            /* Update the baseline of only the Button 24 sensor*/
           	CapSense_UpdateSensorBaseline(CapSense_BUTTON24__BTN);
            /* Check if the Button 24 sensor is active */
            bButtonTouchOnOffStatus = CapSense_CheckIsWidgetActive(CapSense_BUTTON24__BTN);
                    
            CapSense_ScanSensor(CapSense_BUTTON8__BTN);
            while(CapSense_IsBusy() != 0);
            CapSense_UpdateSensorBaseline(CapSense_BUTTON8__BTN);
            CapSense_CheckIsWidgetActive(CapSense_BUTTON8__BTN);
                    
            CapSense_ScanSensor(CapSense_BUTTON9__BTN);
            while(CapSense_IsBusy() != 0);
            CapSense_UpdateSensorBaseline(CapSense_BUTTON9__BTN);
            CapSense_CheckIsWidgetActive(CapSense_BUTTON9__BTN);
                    
            CapSense_ScanSensor(CapSense_BUTTON10__BTN);
            while(CapSense_IsBusy() != 0);
            CapSense_UpdateSensorBaseline(CapSense_BUTTON10__BTN);
            CapSense_CheckIsWidgetActive(CapSense_BUTTON10__BTN);
                    
            CapSense_ScanSensor(CapSense_BUTTON11__BTN);
            while(CapSense_IsBusy() != 0);
            CapSense_UpdateSensorBaseline(CapSense_BUTTON11__BTN);
            CapSense_CheckIsWidgetActive(CapSense_BUTTON11__BTN);
                    
            CapSense_ScanSensor(CapSense_BUTTON12__BTN);
            while(CapSense_IsBusy() != 0);
            CapSense_UpdateSensorBaseline(CapSense_BUTTON12__BTN);
            CapSense_CheckIsWidgetActive(CapSense_BUTTON12__BTN);
                    
            CapSense_ScanSensor(CapSense_BUTTON13__BTN);
            while(CapSense_IsBusy() != 0);
            CapSense_UpdateSensorBaseline(CapSense_BUTTON13__BTN);
            CapSense_CheckIsWidgetActive(CapSense_BUTTON13__BTN);
                    
            /* Filter */
            //더블키 체크 후 눌렸으면 키 제거
            if( (CapSense_sensorOnMask[3] == 0x01) && (CapSense_sensorOnMask[1] & 0x3f) )
            {
                bButtonTouchOnOffStatus = 0;
            }
            //----------------------------------------------------------------------------------          
            if( bButtonTouchOnOffStatus )
            {
                I2CS_Start();
                sleep_flag = 0;   
                Pin_Power_Write(0);
                CySysWdtDisable(CY_SYS_WDT_COUNTER0_MASK);    //WDT counter 0 enable 
            }
        }
        
        
        for(i=0;i<CapSense_TOTAL_SENSOR_COUNT;i++)
        {
            if(CapSense_sensorRaw[i] < 100)
            {
                CySoftwareReset();
            }
        }


       
    //--------------------------------------------------------------------------------------

    CySysWdtResetCounters(CY_SYS_WDT_COUNTER1_RESET);
    
    #ifdef hawkeye
            report_debug_data();          
    #endif
    
    //--------------------------------------------------------------------------------------
    
	}
}

void multikey_check()
{
    unsigned char i, a, count_multi_key = 0;
    
    multikey_flag = 0;
    
    if(CapSense_sensorOnMask[3])
    {
        count_multi_key++;
    }
    
    for(i = 0 ; i < 6 ; i++)
    {
        a = (0x01 << i);
        if( (CapSense_sensorOnMask[1] & a) )
        {
            count_multi_key ++;
        }
    }
    
    if( count_multi_key >= 2 )
    {        
        if( ((CapSense_sensorOnMask[3]) && (CapSense_sensorOnMask[1] == 0x60)) || ((CapSense_sensorOnMask[3]) && (CapSense_sensorOnMask[1] == 0xa0)))
        {
        }
        else
        {
               multikey_flag = 1;
        }
    }      
}

/*============================================================================
Name    :   init_system
------------------------------------------------------------------------------
Purpose :   initialise host app, pins, watchdog, etc
Input   :   n/a
Output  :   n/a
Notes   :
============================================================================*/
static void init_system(void)
{
    /* Configure the wake up period to 100ms */			
    ILODelayCycles_0 = WDT_MATCH_VALUE_20MS;		
    //ILODelayCycles_0 = WDT_MATCH_VALUE_50MS;			
    //ILODelayCycles_0 = WDT_MATCH_VALUE_100MS;			
    //ILODelayCycles_0 = WDT_MATCH_VALUE_200MS;			
    ILODelayCycles_1 = WDT_MATCH_VALUE_2000MS;
    
    /* Map the WatchDog_ISR vector to the WDT_ISR */
    isr_WDT_StartEx(WDT_ISR); 
    
    //WTD Counter0 interrupt Init
    CySysWdtWriteMode(CY_SYS_WDT_COUNTER0,CY_SYS_WDT_MODE_INT);       
    CySysWdtWriteMatch(CY_SYS_WDT_COUNTER0,ILODelayCycles_0);       
	CySysWdtWriteClearOnMatch(CY_SYS_WDT_COUNTER0, 1u); // clear on match enable
    
    /* Enable WDT counters 0 and 1 cascade */
	CySysWdtWriteCascade(CY_SYS_WDT_CASCADE_NONE);
    
    //WTD Counter1 interrupt Init
    CySysWdtWriteMode(CY_SYS_WDT_COUNTER1,CY_SYS_WDT_MODE_RESET);       
    CySysWdtWriteMatch(CY_SYS_WDT_COUNTER1,ILODelayCycles_1);       
	CySysWdtWriteClearOnMatch(CY_SYS_WDT_COUNTER1, 1u); // clear on match enable
}

/******************************************************************************
* Function Name: WDT_ISR_Handler
*******************************************************************************
*
* Summary:
* Interrupt Service Routine for the watchdog timer interrupt. The periodicity 
* of the interrupt is depended on the match value written into the counter 
* register using API - CySysWdtWriteMatch().
*
******************************************************************************/
CY_ISR(WDT_ISR)
{
	/* Clear WDT interrupt */ 
	CySysWdtClearInterrupt(CY_SYS_WDT_COUNTER0_INT);
    CySysWdtClearInterrupt(CY_SYS_WDT_COUNTER1_INT);    
}

/* [] END OF FILE */
