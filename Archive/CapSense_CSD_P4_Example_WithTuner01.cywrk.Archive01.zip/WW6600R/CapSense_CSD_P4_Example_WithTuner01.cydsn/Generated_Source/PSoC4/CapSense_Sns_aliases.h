/*******************************************************************************
* File Name: CapSense_Sns.h  
* Version 2.10
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_CapSense_Sns_ALIASES_H) /* Pins CapSense_Sns_ALIASES_H */
#define CY_PINS_CapSense_Sns_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define CapSense_Sns_0		(CapSense_Sns__0__PC)
#define CapSense_Sns_0_PS		(CapSense_Sns__0__PS)
#define CapSense_Sns_0_PC		(CapSense_Sns__0__PC)
#define CapSense_Sns_0_DR		(CapSense_Sns__0__DR)
#define CapSense_Sns_0_SHIFT	(CapSense_Sns__0__SHIFT)

#define CapSense_Sns_1		(CapSense_Sns__1__PC)
#define CapSense_Sns_1_PS		(CapSense_Sns__1__PS)
#define CapSense_Sns_1_PC		(CapSense_Sns__1__PC)
#define CapSense_Sns_1_DR		(CapSense_Sns__1__DR)
#define CapSense_Sns_1_SHIFT	(CapSense_Sns__1__SHIFT)

#define CapSense_Sns_2		(CapSense_Sns__2__PC)
#define CapSense_Sns_2_PS		(CapSense_Sns__2__PS)
#define CapSense_Sns_2_PC		(CapSense_Sns__2__PC)
#define CapSense_Sns_2_DR		(CapSense_Sns__2__DR)
#define CapSense_Sns_2_SHIFT	(CapSense_Sns__2__SHIFT)

#define CapSense_Sns_3		(CapSense_Sns__3__PC)
#define CapSense_Sns_3_PS		(CapSense_Sns__3__PS)
#define CapSense_Sns_3_PC		(CapSense_Sns__3__PC)
#define CapSense_Sns_3_DR		(CapSense_Sns__3__DR)
#define CapSense_Sns_3_SHIFT	(CapSense_Sns__3__SHIFT)

#define CapSense_Sns_4		(CapSense_Sns__4__PC)
#define CapSense_Sns_4_PS		(CapSense_Sns__4__PS)
#define CapSense_Sns_4_PC		(CapSense_Sns__4__PC)
#define CapSense_Sns_4_DR		(CapSense_Sns__4__DR)
#define CapSense_Sns_4_SHIFT	(CapSense_Sns__4__SHIFT)

#define CapSense_Sns_5		(CapSense_Sns__5__PC)
#define CapSense_Sns_5_PS		(CapSense_Sns__5__PS)
#define CapSense_Sns_5_PC		(CapSense_Sns__5__PC)
#define CapSense_Sns_5_DR		(CapSense_Sns__5__DR)
#define CapSense_Sns_5_SHIFT	(CapSense_Sns__5__SHIFT)

#define CapSense_Sns_6		(CapSense_Sns__6__PC)
#define CapSense_Sns_6_PS		(CapSense_Sns__6__PS)
#define CapSense_Sns_6_PC		(CapSense_Sns__6__PC)
#define CapSense_Sns_6_DR		(CapSense_Sns__6__DR)
#define CapSense_Sns_6_SHIFT	(CapSense_Sns__6__SHIFT)

#define CapSense_Sns_7		(CapSense_Sns__7__PC)
#define CapSense_Sns_7_PS		(CapSense_Sns__7__PS)
#define CapSense_Sns_7_PC		(CapSense_Sns__7__PC)
#define CapSense_Sns_7_DR		(CapSense_Sns__7__DR)
#define CapSense_Sns_7_SHIFT	(CapSense_Sns__7__SHIFT)

#define CapSense_Sns_8		(CapSense_Sns__8__PC)
#define CapSense_Sns_8_PS		(CapSense_Sns__8__PS)
#define CapSense_Sns_8_PC		(CapSense_Sns__8__PC)
#define CapSense_Sns_8_DR		(CapSense_Sns__8__DR)
#define CapSense_Sns_8_SHIFT	(CapSense_Sns__8__SHIFT)

#define CapSense_Sns_9		(CapSense_Sns__9__PC)
#define CapSense_Sns_9_PS		(CapSense_Sns__9__PS)
#define CapSense_Sns_9_PC		(CapSense_Sns__9__PC)
#define CapSense_Sns_9_DR		(CapSense_Sns__9__DR)
#define CapSense_Sns_9_SHIFT	(CapSense_Sns__9__SHIFT)

#define CapSense_Sns_10		(CapSense_Sns__10__PC)
#define CapSense_Sns_10_PS		(CapSense_Sns__10__PS)
#define CapSense_Sns_10_PC		(CapSense_Sns__10__PC)
#define CapSense_Sns_10_DR		(CapSense_Sns__10__DR)
#define CapSense_Sns_10_SHIFT	(CapSense_Sns__10__SHIFT)

#define CapSense_Sns_11		(CapSense_Sns__11__PC)
#define CapSense_Sns_11_PS		(CapSense_Sns__11__PS)
#define CapSense_Sns_11_PC		(CapSense_Sns__11__PC)
#define CapSense_Sns_11_DR		(CapSense_Sns__11__DR)
#define CapSense_Sns_11_SHIFT	(CapSense_Sns__11__SHIFT)

#define CapSense_Sns_12		(CapSense_Sns__12__PC)
#define CapSense_Sns_12_PS		(CapSense_Sns__12__PS)
#define CapSense_Sns_12_PC		(CapSense_Sns__12__PC)
#define CapSense_Sns_12_DR		(CapSense_Sns__12__DR)
#define CapSense_Sns_12_SHIFT	(CapSense_Sns__12__SHIFT)

#define CapSense_Sns_13		(CapSense_Sns__13__PC)
#define CapSense_Sns_13_PS		(CapSense_Sns__13__PS)
#define CapSense_Sns_13_PC		(CapSense_Sns__13__PC)
#define CapSense_Sns_13_DR		(CapSense_Sns__13__DR)
#define CapSense_Sns_13_SHIFT	(CapSense_Sns__13__SHIFT)

#define CapSense_Sns_14		(CapSense_Sns__14__PC)
#define CapSense_Sns_14_PS		(CapSense_Sns__14__PS)
#define CapSense_Sns_14_PC		(CapSense_Sns__14__PC)
#define CapSense_Sns_14_DR		(CapSense_Sns__14__DR)
#define CapSense_Sns_14_SHIFT	(CapSense_Sns__14__SHIFT)

#define CapSense_Sns_15		(CapSense_Sns__15__PC)
#define CapSense_Sns_15_PS		(CapSense_Sns__15__PS)
#define CapSense_Sns_15_PC		(CapSense_Sns__15__PC)
#define CapSense_Sns_15_DR		(CapSense_Sns__15__DR)
#define CapSense_Sns_15_SHIFT	(CapSense_Sns__15__SHIFT)

#define CapSense_Sns_16		(CapSense_Sns__16__PC)
#define CapSense_Sns_16_PS		(CapSense_Sns__16__PS)
#define CapSense_Sns_16_PC		(CapSense_Sns__16__PC)
#define CapSense_Sns_16_DR		(CapSense_Sns__16__DR)
#define CapSense_Sns_16_SHIFT	(CapSense_Sns__16__SHIFT)

#define CapSense_Sns_17		(CapSense_Sns__17__PC)
#define CapSense_Sns_17_PS		(CapSense_Sns__17__PS)
#define CapSense_Sns_17_PC		(CapSense_Sns__17__PC)
#define CapSense_Sns_17_DR		(CapSense_Sns__17__DR)
#define CapSense_Sns_17_SHIFT	(CapSense_Sns__17__SHIFT)

#define CapSense_Sns_18		(CapSense_Sns__18__PC)
#define CapSense_Sns_18_PS		(CapSense_Sns__18__PS)
#define CapSense_Sns_18_PC		(CapSense_Sns__18__PC)
#define CapSense_Sns_18_DR		(CapSense_Sns__18__DR)
#define CapSense_Sns_18_SHIFT	(CapSense_Sns__18__SHIFT)

#define CapSense_Sns_19		(CapSense_Sns__19__PC)
#define CapSense_Sns_19_PS		(CapSense_Sns__19__PS)
#define CapSense_Sns_19_PC		(CapSense_Sns__19__PC)
#define CapSense_Sns_19_DR		(CapSense_Sns__19__DR)
#define CapSense_Sns_19_SHIFT	(CapSense_Sns__19__SHIFT)

#define CapSense_Sns_20		(CapSense_Sns__20__PC)
#define CapSense_Sns_20_PS		(CapSense_Sns__20__PS)
#define CapSense_Sns_20_PC		(CapSense_Sns__20__PC)
#define CapSense_Sns_20_DR		(CapSense_Sns__20__DR)
#define CapSense_Sns_20_SHIFT	(CapSense_Sns__20__SHIFT)

#define CapSense_Sns_21		(CapSense_Sns__21__PC)
#define CapSense_Sns_21_PS		(CapSense_Sns__21__PS)
#define CapSense_Sns_21_PC		(CapSense_Sns__21__PC)
#define CapSense_Sns_21_DR		(CapSense_Sns__21__DR)
#define CapSense_Sns_21_SHIFT	(CapSense_Sns__21__SHIFT)

#define CapSense_Sns_22		(CapSense_Sns__22__PC)
#define CapSense_Sns_22_PS		(CapSense_Sns__22__PS)
#define CapSense_Sns_22_PC		(CapSense_Sns__22__PC)
#define CapSense_Sns_22_DR		(CapSense_Sns__22__DR)
#define CapSense_Sns_22_SHIFT	(CapSense_Sns__22__SHIFT)

#define CapSense_Sns_23		(CapSense_Sns__23__PC)
#define CapSense_Sns_23_PS		(CapSense_Sns__23__PS)
#define CapSense_Sns_23_PC		(CapSense_Sns__23__PC)
#define CapSense_Sns_23_DR		(CapSense_Sns__23__DR)
#define CapSense_Sns_23_SHIFT	(CapSense_Sns__23__SHIFT)

#define CapSense_Sns_24		(CapSense_Sns__24__PC)
#define CapSense_Sns_24_PS		(CapSense_Sns__24__PS)
#define CapSense_Sns_24_PC		(CapSense_Sns__24__PC)
#define CapSense_Sns_24_DR		(CapSense_Sns__24__DR)
#define CapSense_Sns_24_SHIFT	(CapSense_Sns__24__SHIFT)

#define CapSense_Sns_25		(CapSense_Sns__25__PC)
#define CapSense_Sns_25_PS		(CapSense_Sns__25__PS)
#define CapSense_Sns_25_PC		(CapSense_Sns__25__PC)
#define CapSense_Sns_25_DR		(CapSense_Sns__25__DR)
#define CapSense_Sns_25_SHIFT	(CapSense_Sns__25__SHIFT)


#define CapSense_Sns_Button0__BTN		(CapSense_Sns__Button0__BTN__PC)
#define CapSense_Sns_Button0__BTN_PS		(CapSense_Sns__Button0__BTN__PS)
#define CapSense_Sns_Button0__BTN_PC		(CapSense_Sns__Button0__BTN__PC)
#define CapSense_Sns_Button0__BTN_DR		(CapSense_Sns__Button0__BTN__DR)
#define CapSense_Sns_Button0__BTN_SHIFT	(CapSense_Sns__Button0__BTN__SHIFT)

#define CapSense_Sns_Button1__BTN		(CapSense_Sns__Button1__BTN__PC)
#define CapSense_Sns_Button1__BTN_PS		(CapSense_Sns__Button1__BTN__PS)
#define CapSense_Sns_Button1__BTN_PC		(CapSense_Sns__Button1__BTN__PC)
#define CapSense_Sns_Button1__BTN_DR		(CapSense_Sns__Button1__BTN__DR)
#define CapSense_Sns_Button1__BTN_SHIFT	(CapSense_Sns__Button1__BTN__SHIFT)

#define CapSense_Sns_Button2__BTN		(CapSense_Sns__Button2__BTN__PC)
#define CapSense_Sns_Button2__BTN_PS		(CapSense_Sns__Button2__BTN__PS)
#define CapSense_Sns_Button2__BTN_PC		(CapSense_Sns__Button2__BTN__PC)
#define CapSense_Sns_Button2__BTN_DR		(CapSense_Sns__Button2__BTN__DR)
#define CapSense_Sns_Button2__BTN_SHIFT	(CapSense_Sns__Button2__BTN__SHIFT)

#define CapSense_Sns_Button3__BTN		(CapSense_Sns__Button3__BTN__PC)
#define CapSense_Sns_Button3__BTN_PS		(CapSense_Sns__Button3__BTN__PS)
#define CapSense_Sns_Button3__BTN_PC		(CapSense_Sns__Button3__BTN__PC)
#define CapSense_Sns_Button3__BTN_DR		(CapSense_Sns__Button3__BTN__DR)
#define CapSense_Sns_Button3__BTN_SHIFT	(CapSense_Sns__Button3__BTN__SHIFT)

#define CapSense_Sns_Button4__BTN		(CapSense_Sns__Button4__BTN__PC)
#define CapSense_Sns_Button4__BTN_PS		(CapSense_Sns__Button4__BTN__PS)
#define CapSense_Sns_Button4__BTN_PC		(CapSense_Sns__Button4__BTN__PC)
#define CapSense_Sns_Button4__BTN_DR		(CapSense_Sns__Button4__BTN__DR)
#define CapSense_Sns_Button4__BTN_SHIFT	(CapSense_Sns__Button4__BTN__SHIFT)

#define CapSense_Sns_Button5__BTN		(CapSense_Sns__Button5__BTN__PC)
#define CapSense_Sns_Button5__BTN_PS		(CapSense_Sns__Button5__BTN__PS)
#define CapSense_Sns_Button5__BTN_PC		(CapSense_Sns__Button5__BTN__PC)
#define CapSense_Sns_Button5__BTN_DR		(CapSense_Sns__Button5__BTN__DR)
#define CapSense_Sns_Button5__BTN_SHIFT	(CapSense_Sns__Button5__BTN__SHIFT)

#define CapSense_Sns_Button6__BTN		(CapSense_Sns__Button6__BTN__PC)
#define CapSense_Sns_Button6__BTN_PS		(CapSense_Sns__Button6__BTN__PS)
#define CapSense_Sns_Button6__BTN_PC		(CapSense_Sns__Button6__BTN__PC)
#define CapSense_Sns_Button6__BTN_DR		(CapSense_Sns__Button6__BTN__DR)
#define CapSense_Sns_Button6__BTN_SHIFT	(CapSense_Sns__Button6__BTN__SHIFT)

#define CapSense_Sns_Button7__BTN		(CapSense_Sns__Button7__BTN__PC)
#define CapSense_Sns_Button7__BTN_PS		(CapSense_Sns__Button7__BTN__PS)
#define CapSense_Sns_Button7__BTN_PC		(CapSense_Sns__Button7__BTN__PC)
#define CapSense_Sns_Button7__BTN_DR		(CapSense_Sns__Button7__BTN__DR)
#define CapSense_Sns_Button7__BTN_SHIFT	(CapSense_Sns__Button7__BTN__SHIFT)

#define CapSense_Sns_Button8__BTN		(CapSense_Sns__Button8__BTN__PC)
#define CapSense_Sns_Button8__BTN_PS		(CapSense_Sns__Button8__BTN__PS)
#define CapSense_Sns_Button8__BTN_PC		(CapSense_Sns__Button8__BTN__PC)
#define CapSense_Sns_Button8__BTN_DR		(CapSense_Sns__Button8__BTN__DR)
#define CapSense_Sns_Button8__BTN_SHIFT	(CapSense_Sns__Button8__BTN__SHIFT)

#define CapSense_Sns_Button9__BTN		(CapSense_Sns__Button9__BTN__PC)
#define CapSense_Sns_Button9__BTN_PS		(CapSense_Sns__Button9__BTN__PS)
#define CapSense_Sns_Button9__BTN_PC		(CapSense_Sns__Button9__BTN__PC)
#define CapSense_Sns_Button9__BTN_DR		(CapSense_Sns__Button9__BTN__DR)
#define CapSense_Sns_Button9__BTN_SHIFT	(CapSense_Sns__Button9__BTN__SHIFT)

#define CapSense_Sns_Button10__BTN		(CapSense_Sns__Button10__BTN__PC)
#define CapSense_Sns_Button10__BTN_PS		(CapSense_Sns__Button10__BTN__PS)
#define CapSense_Sns_Button10__BTN_PC		(CapSense_Sns__Button10__BTN__PC)
#define CapSense_Sns_Button10__BTN_DR		(CapSense_Sns__Button10__BTN__DR)
#define CapSense_Sns_Button10__BTN_SHIFT	(CapSense_Sns__Button10__BTN__SHIFT)

#define CapSense_Sns_Button11__BTN		(CapSense_Sns__Button11__BTN__PC)
#define CapSense_Sns_Button11__BTN_PS		(CapSense_Sns__Button11__BTN__PS)
#define CapSense_Sns_Button11__BTN_PC		(CapSense_Sns__Button11__BTN__PC)
#define CapSense_Sns_Button11__BTN_DR		(CapSense_Sns__Button11__BTN__DR)
#define CapSense_Sns_Button11__BTN_SHIFT	(CapSense_Sns__Button11__BTN__SHIFT)

#define CapSense_Sns_Button12__BTN		(CapSense_Sns__Button12__BTN__PC)
#define CapSense_Sns_Button12__BTN_PS		(CapSense_Sns__Button12__BTN__PS)
#define CapSense_Sns_Button12__BTN_PC		(CapSense_Sns__Button12__BTN__PC)
#define CapSense_Sns_Button12__BTN_DR		(CapSense_Sns__Button12__BTN__DR)
#define CapSense_Sns_Button12__BTN_SHIFT	(CapSense_Sns__Button12__BTN__SHIFT)

#define CapSense_Sns_Button13__BTN		(CapSense_Sns__Button13__BTN__PC)
#define CapSense_Sns_Button13__BTN_PS		(CapSense_Sns__Button13__BTN__PS)
#define CapSense_Sns_Button13__BTN_PC		(CapSense_Sns__Button13__BTN__PC)
#define CapSense_Sns_Button13__BTN_DR		(CapSense_Sns__Button13__BTN__DR)
#define CapSense_Sns_Button13__BTN_SHIFT	(CapSense_Sns__Button13__BTN__SHIFT)

#define CapSense_Sns_Button14__BTN		(CapSense_Sns__Button14__BTN__PC)
#define CapSense_Sns_Button14__BTN_PS		(CapSense_Sns__Button14__BTN__PS)
#define CapSense_Sns_Button14__BTN_PC		(CapSense_Sns__Button14__BTN__PC)
#define CapSense_Sns_Button14__BTN_DR		(CapSense_Sns__Button14__BTN__DR)
#define CapSense_Sns_Button14__BTN_SHIFT	(CapSense_Sns__Button14__BTN__SHIFT)

#define CapSense_Sns_Button15__BTN		(CapSense_Sns__Button15__BTN__PC)
#define CapSense_Sns_Button15__BTN_PS		(CapSense_Sns__Button15__BTN__PS)
#define CapSense_Sns_Button15__BTN_PC		(CapSense_Sns__Button15__BTN__PC)
#define CapSense_Sns_Button15__BTN_DR		(CapSense_Sns__Button15__BTN__DR)
#define CapSense_Sns_Button15__BTN_SHIFT	(CapSense_Sns__Button15__BTN__SHIFT)

#define CapSense_Sns_Button16__BTN		(CapSense_Sns__Button16__BTN__PC)
#define CapSense_Sns_Button16__BTN_PS		(CapSense_Sns__Button16__BTN__PS)
#define CapSense_Sns_Button16__BTN_PC		(CapSense_Sns__Button16__BTN__PC)
#define CapSense_Sns_Button16__BTN_DR		(CapSense_Sns__Button16__BTN__DR)
#define CapSense_Sns_Button16__BTN_SHIFT	(CapSense_Sns__Button16__BTN__SHIFT)

#define CapSense_Sns_Button17__BTN		(CapSense_Sns__Button17__BTN__PC)
#define CapSense_Sns_Button17__BTN_PS		(CapSense_Sns__Button17__BTN__PS)
#define CapSense_Sns_Button17__BTN_PC		(CapSense_Sns__Button17__BTN__PC)
#define CapSense_Sns_Button17__BTN_DR		(CapSense_Sns__Button17__BTN__DR)
#define CapSense_Sns_Button17__BTN_SHIFT	(CapSense_Sns__Button17__BTN__SHIFT)

#define CapSense_Sns_Button18__BTN		(CapSense_Sns__Button18__BTN__PC)
#define CapSense_Sns_Button18__BTN_PS		(CapSense_Sns__Button18__BTN__PS)
#define CapSense_Sns_Button18__BTN_PC		(CapSense_Sns__Button18__BTN__PC)
#define CapSense_Sns_Button18__BTN_DR		(CapSense_Sns__Button18__BTN__DR)
#define CapSense_Sns_Button18__BTN_SHIFT	(CapSense_Sns__Button18__BTN__SHIFT)

#define CapSense_Sns_Button19__BTN		(CapSense_Sns__Button19__BTN__PC)
#define CapSense_Sns_Button19__BTN_PS		(CapSense_Sns__Button19__BTN__PS)
#define CapSense_Sns_Button19__BTN_PC		(CapSense_Sns__Button19__BTN__PC)
#define CapSense_Sns_Button19__BTN_DR		(CapSense_Sns__Button19__BTN__DR)
#define CapSense_Sns_Button19__BTN_SHIFT	(CapSense_Sns__Button19__BTN__SHIFT)

#define CapSense_Sns_Button20__BTN		(CapSense_Sns__Button20__BTN__PC)
#define CapSense_Sns_Button20__BTN_PS		(CapSense_Sns__Button20__BTN__PS)
#define CapSense_Sns_Button20__BTN_PC		(CapSense_Sns__Button20__BTN__PC)
#define CapSense_Sns_Button20__BTN_DR		(CapSense_Sns__Button20__BTN__DR)
#define CapSense_Sns_Button20__BTN_SHIFT	(CapSense_Sns__Button20__BTN__SHIFT)

#define CapSense_Sns_Button21__BTN		(CapSense_Sns__Button21__BTN__PC)
#define CapSense_Sns_Button21__BTN_PS		(CapSense_Sns__Button21__BTN__PS)
#define CapSense_Sns_Button21__BTN_PC		(CapSense_Sns__Button21__BTN__PC)
#define CapSense_Sns_Button21__BTN_DR		(CapSense_Sns__Button21__BTN__DR)
#define CapSense_Sns_Button21__BTN_SHIFT	(CapSense_Sns__Button21__BTN__SHIFT)

#define CapSense_Sns_Button22__BTN		(CapSense_Sns__Button22__BTN__PC)
#define CapSense_Sns_Button22__BTN_PS		(CapSense_Sns__Button22__BTN__PS)
#define CapSense_Sns_Button22__BTN_PC		(CapSense_Sns__Button22__BTN__PC)
#define CapSense_Sns_Button22__BTN_DR		(CapSense_Sns__Button22__BTN__DR)
#define CapSense_Sns_Button22__BTN_SHIFT	(CapSense_Sns__Button22__BTN__SHIFT)

#define CapSense_Sns_Button23__BTN		(CapSense_Sns__Button23__BTN__PC)
#define CapSense_Sns_Button23__BTN_PS		(CapSense_Sns__Button23__BTN__PS)
#define CapSense_Sns_Button23__BTN_PC		(CapSense_Sns__Button23__BTN__PC)
#define CapSense_Sns_Button23__BTN_DR		(CapSense_Sns__Button23__BTN__DR)
#define CapSense_Sns_Button23__BTN_SHIFT	(CapSense_Sns__Button23__BTN__SHIFT)

#define CapSense_Sns_Button24__BTN		(CapSense_Sns__Button24__BTN__PC)
#define CapSense_Sns_Button24__BTN_PS		(CapSense_Sns__Button24__BTN__PS)
#define CapSense_Sns_Button24__BTN_PC		(CapSense_Sns__Button24__BTN__PC)
#define CapSense_Sns_Button24__BTN_DR		(CapSense_Sns__Button24__BTN__DR)
#define CapSense_Sns_Button24__BTN_SHIFT	(CapSense_Sns__Button24__BTN__SHIFT)

#define CapSense_Sns_Button25__BTN		(CapSense_Sns__Button25__BTN__PC)
#define CapSense_Sns_Button25__BTN_PS		(CapSense_Sns__Button25__BTN__PS)
#define CapSense_Sns_Button25__BTN_PC		(CapSense_Sns__Button25__BTN__PC)
#define CapSense_Sns_Button25__BTN_DR		(CapSense_Sns__Button25__BTN__DR)
#define CapSense_Sns_Button25__BTN_SHIFT	(CapSense_Sns__Button25__BTN__SHIFT)


#endif /* End Pins CapSense_Sns_ALIASES_H */


/* [] END OF FILE */
